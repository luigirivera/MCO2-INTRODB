package model;

public class Favorite {
	public static final String TABLE = "favorite";
	public static final String COL_USER = "user";
	public static final String COL_PRODUCT = "product";
}
