package model;

public class CartContent {
	public static final String TABLE = "cartcontent";
	public static final String COL_ID = "cartid";
	public static final String COL_USER = "userid";
	public static final String COL_PRODUCT = "productid";
	public static final String COL_QUANTITY = "quantity";
}
