package model;

public class Following {
	public static final String TABLE = "following";
	public static final String COL_USER = "user";
	public static final String COL_FOLLOWER = "follower";
}
